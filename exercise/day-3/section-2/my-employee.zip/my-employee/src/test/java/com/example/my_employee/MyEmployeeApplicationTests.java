package com.example.my_employee;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyEmployeeApplicationTests {

	@Test
	void contextLoads() {
	}

}
