package com.example.my_employee;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyEmployeeApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyEmployeeApplication.class, args);
	}

}
