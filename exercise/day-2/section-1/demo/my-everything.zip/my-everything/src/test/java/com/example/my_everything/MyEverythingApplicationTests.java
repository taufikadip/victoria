package com.example.my_everything;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyEverythingApplicationTests {

	@Test
	void contextLoads() {
	}

}
